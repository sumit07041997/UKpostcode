This library validates the formatting of UK post codes. Also gives the Inward and Outward codes. 
This library can also fetch address of a post code.

This library used geopy and poscodes.io Api